package HW_12����;

public class StringConvertExample {
	public static void main(String[] args) {
		//String->int
		String strData1 = "200";
		int intData1 = Integer.parseInt(strData1);
		
		
		//int->String
		int intData2 = 150;
		String strData2 = Integer.toString(intData2);
	}

}

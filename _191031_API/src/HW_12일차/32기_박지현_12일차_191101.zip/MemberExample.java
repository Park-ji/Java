package HW_12����;

public class MemberExample {
	public static void main(String[] args) {
		Member member = new Member("blue", "���Ķ�");
		System.out.println(member);
	}

}

package pjh_20191015;

public class Exercise5 {
	public static void main(String[] args) {
		int num = 333;
		System.out.println((num/10)*10+1);
	}

}

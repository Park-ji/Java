package pjh_20191015;

public class Exercise6 {
	public static void main(String[] args) {
		int num = 24;
		System.out.println(((num/10+1)*10)-num);
	}

}



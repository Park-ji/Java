package pjh_20191015;

public class Exercise3 {
	public static void main(String[] args) {
		int num =10;
		System.out.println(num==0?"0":(num>0?"���":"����"));
	}
}
